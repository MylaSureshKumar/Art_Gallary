import axios from 'axios';

const ART_API_BASE_URL = "http://localhost:8080/api/v1";

class ArtService {
    getArts() {
        return axios.get(`${ART_API_BASE_URL}/artworks`);
    }

    createArt(art) {
        // Assuming the backend handles multipart form-data
        return axios.post(`${ART_API_BASE_URL}/artworks`, art, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    }

    getArtById(artId) {
        return axios.get(`${ART_API_BASE_URL}/artworks/${artId}`);
    }

    updateArt(art, artId) {
        // Assuming the backend handles multipart form-data
        return axios.put(`${ART_API_BASE_URL}/artworks/${artId}`, art, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
    }

    deleteArt(artId) {
        return axios.delete(`${ART_API_BASE_URL}/artworks/${artId}`);
    }

    getArtCategory(artId) {
        return axios.get(`${ART_API_BASE_URL}/artworks/${artId}/artCategory`);
    }
}

export default new ArtService();
