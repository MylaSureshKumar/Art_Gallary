// App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import LoginComponent from './components/LoginComponent';
import ListArtComponent from './components/ListArtComponent';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateArtComponent from './components/CreateArtComponent';
import UpdateArtComponent from './components/UpdateArtComponent';
import ViewArtComponent from './components/ViewArtComponent';
import ExhibitionComponent from './components/ExhibitionComponent';
import BuyArtComponent from './components/BuyArtComponent';
import RegisterComponent from './components/RegisterComponent';

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    return (
        <Router>
            <HeaderComponent />
            <div className="container">
                <Switch>
                    <Route path="/login">
                        <LoginComponent setIsLoggedIn={setIsLoggedIn} />
                    </Route>
                    <Route path="/register" component={RegisterComponent} />
                    {isLoggedIn ? (
                        <>
                            <Route path="/" exact component={ListArtComponent} />
                            <Route path="/artworks" component={ListArtComponent} />
                            <Route path="/add-art/:id" component={CreateArtComponent} />
                            <Route path="/view-art/:id" component={ViewArtComponent} />
                            <Route path="/update-art/:id" component={UpdateArtComponent} />
                            <Route path="/exhibition" component={ExhibitionComponent} />
                            <Route path="/buy-art/:id" component={BuyArtComponent} />
                        </>
                    ) : (
                        <Redirect to="/login" />
                    )}
                    <Redirect to="/login" />
                </Switch>
            </div>
            <FooterComponent />
        </Router>
    );
}

export default App;
