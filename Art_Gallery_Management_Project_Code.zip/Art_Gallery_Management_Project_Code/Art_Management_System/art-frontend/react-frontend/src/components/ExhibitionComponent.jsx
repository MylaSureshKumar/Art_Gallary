import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import ArtService from '../services/ArtService';
import '../style3.css';

class ExhibitionComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            artworks: [],
            to: 'sureshmyla6@gmail.com',
            subject: '',
            body: '',
            sending: false,
            sent: false,
            error: null,
            sentEmails: []
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {
        this.fetchArtworks();
    }

    fetchArtworks() {
        ArtService.getArts().then((res) => {
            this.setState({ artworks: res.data });
        }).catch(err => {
            console.error("There was an error fetching the artworks!", err);
        });
    }

    handleBuy(artId) {
        this.props.history.push(`/buy-art/${artId}`);
    }

    handleChange(event) {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    handleSubmit(event) {
        event.preventDefault();
        this.setState({ sending: true, sent: false, error: null });

        // Simulate sending email
        setTimeout(() => {
            const { to, subject, body } = this.state;
            const email = {
                to,
                subject,
                body,
                timestamp: new Date()
            };
            this.setState((prevState) => ({
                sending: false,
                sent: true,
                sentEmails: [...prevState.sentEmails, email]
            }));
        }, 1000);
    }

    render() {
        const { artworks, to, subject, body, sending, sent, error, sentEmails } = this.state;
        return (
            <div className="container">
                <header>
                    <nav className="navbar navbar-expand-lg navbar-light bg-light">
                        <a className="navbar-brand" href="#">Art Gallery</a>
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <a className="nav-link" href="#home">Home</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#about">About Us</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#contact">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header>

                <section id="home">
                    <div className="container">
                        <h2 className="text-center">Current Exhibition</h2>
                        <p>
                            Welcome to our current exhibition. Here you can find a curated selection of our latest artworks on display. 
                            Explore the collection and immerse yourself in the beauty of art.
                        </p>
                        <div className="row">
                            {artworks.map((art) => (
                                <div className="col-md-4 mb-4" key={art.id}>
                                    <div className="card h-100">
                                        {art.image && (
                                            <img
                                                src={`data:image/jpeg;base64,${art.image}`}
                                                alt={art.title}
                                                className="card-img-top exhibition-image"
                                            />
                                        )}
                                        <div className="card-body">
                                            <h5 className="card-title">{art.title}</h5>
                                            <p className="card-text">{art.artist}</p>
                                            <button
                                                className="btn btn-add"
                                                onClick={() => this.handleBuy(art.id)}
                                            >
                                                Buy
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
                
                <section id="about">
                    <div className="container">
                        <h2 className="text-center">About Us</h2>
                        <p>
                            Welcome to our Art Gallery. We are dedicated to showcasing and promoting art from 
                            talented artists around the world. Our collection includes a wide range of artworks 
                            including paintings, sculptures, photographs, and digital art pieces. We strive to 
                            provide a platform where artists can exhibit their work and art enthusiasts can 
                            discover and purchase unique pieces.
                        </p>
                    </div>
                </section>

                <section id="contact">
                    <div className="container">
                        <h2 className="text-center">Contact Us</h2>
                        <p>
                            If you have any questions or would like to know more about our gallery, please feel 
                            free to reach out to us.
                        </p>
                        <div>
                            <h2 className="text-center">Send Email</h2>
                            <form onSubmit={this.handleSubmit}>
                                <div className="form-group">
                                    <label htmlFor="to">To:</label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        id="to"
                                        name="to"
                                        value={to}
                                        onChange={this.handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="subject">Subject:</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="subject"
                                        name="subject"
                                        value={subject}
                                        onChange={this.handleChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="body">Body:</label>
                                    <textarea
                                        className="form-control"
                                        id="body"
                                        name="body"
                                        value={body}
                                        onChange={this.handleChange}
                                        rows="5"
                                        required
                                    />
                                </div>
                                <button type="submit" className="btn btn-add" disabled={sending}>
                                    {sending ? 'Sending...' : 'Send'}
                                </button>
                                {sent && <p>Email sent successfully!</p>}
                                {error && <p>Error: {error}</p>}
                            </form>

                            {/* Display sent emails in history */}
                            {sentEmails.length > 0 && (
                                <div>
                                    <h3 className="text-center">Sent Email History</h3>
                                    <ul>
                                        {sentEmails.map((email, index) => (
                                            <li key={index}>
                                                To: {email.to}, Subject: {email.subject}, Body: {email.body}, Time: {email.timestamp.toString()}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                    </div>
                </section>

                <footer className="bg-light text-center text-lg-start">
                    <div className="container p-4">
                        <div className="row">
                            <div className="col-lg-6 col-md-12 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Art Gallery</h5>
                                <p>
                                    Bringing art closer to people. Discover, appreciate, and purchase art from our 
                                    diverse collection.
                                </p>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Links</h5>
                                <ul className="list-unstyled mb-0">
                                    <li><a href="#home" className="text-dark">Home</a></li>
                                    <li><a href="#about" className="text-dark">About Us</a></li>
                                    <li><a href="#contact" className="text-dark">Contact Us</a></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Follow Us</h5>
                                <ul className="list-unstyled mb-0">
                                    <li><a href="#!" className="text-dark">Facebook</a></li>
                                    <li><a href="#!" className="text-dark">Twitter</a></li>
                                    <li><a href="#!" className="text-dark">Instagram</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="text-center p-3">
                        © 2024 Art Gallery. All rights reserved.
                    </div>
                </footer>
            </div>
        );
    }
}

export default withRouter(ExhibitionComponent);
