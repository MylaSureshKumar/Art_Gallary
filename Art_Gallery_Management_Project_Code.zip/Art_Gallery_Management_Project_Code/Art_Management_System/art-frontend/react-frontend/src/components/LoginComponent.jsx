import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

const LoginComponent = ({ setIsLoggedIn }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('user'); 
    const history = useHistory();

    const handleLogin = async () => {
        try {
            const response = await axios.post('http://localhost:8080/api/v1/login', {
                username,
                password,
                role,
            });
            console.log('Login successful:', response.data);
            setIsLoggedIn(true);
            if (role === 'admin') {
                history.push('/artworks');
            } else {
                history.push('/exhibition');
            }
        } catch (error) {
            console.error('Login failed:', error);
            alert('Invalid username, password, or role');
        }
    };

    return (
        <div className="container">
            <div className="row justify-content-center mt-5">
                <div className="col-md-5">
                    <div className="card">
                        <div className="card-body">
                            <h2 className="card-title text-center">Login</h2>
                            <form>
                                <div className="form-group">
                                    <label>Username:</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={username}
                                        onChange={(e) => setUsername(e.target.value)}
                                        placeholder="Enter your username"
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Password:</label>
                                    <input
                                        type="password"
                                        className="form-control"
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="Enter your password"
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Role:</label>
                                    <select
                                        className="form-control"
                                        value={role}
                                        onChange={(e) => setRole(e.target.value)}
                                    >
                                        <option value="user">User</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>
                                <button
                                    type="button"
                                    className="btn btn-add btn-block"
                                    onClick={handleLogin}
                                >
                                    Login
                                </button>
                            </form>
                            <div className="text-center mt-3">
                                <button
                                    className="btn btn-add"
                                    onClick={() => history.push('/register')}
                                >
                                    Register
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginComponent;
