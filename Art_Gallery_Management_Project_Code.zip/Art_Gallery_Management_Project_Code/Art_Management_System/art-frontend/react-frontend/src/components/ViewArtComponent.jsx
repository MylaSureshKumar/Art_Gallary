import React, { Component } from 'react';
import ArtService from '../services/ArtService';
import '../styles1.css';

class ViewArtComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: this.props.match.params.id,
            art: {},
            artCategory: '', // Initialize category state
            image: '' // Initialize image URL state
        };
    }

    componentDidMount() {
        ArtService.getArtById(this.state.id).then((res) => {
            const art = res.data;
            this.setState({ 
                art,
                artCategory: art.artCategory, // Assuming category is part of art data
                image: art.image ? `data:image/png;base64,${art.image}` : '' // Assuming image data is base64 encoded
            });
        });
    }

    render() {
        const transparentBackground = {
            backgroundColor: 'rgba(255, 255, 255, 0.5)',
            padding: '20px',
            borderRadius: '10px'
        };

        return (
            <div>
                <br />
                <div className="card col-md-6 offset-md-3" style={transparentBackground}>
                    <h3 className="text-center"> View Art Details</h3>
                    <div className="card-body">
                        <div className="row">
                            <label> Image: </label>
                            <div>
                                {this.state.image && (
                                    <img src={this.state.image} alt={this.state.art.title} className="img-fluid" />
                                )}
                            </div>
                        </div>
                        <div className="row">
                            <label> Title: </label>
                            <div> {this.state.art.title}</div>
                        </div>
                        <div className="row">
                            <label> Artist: </label>
                            <div> {this.state.art.artist}</div>
                        </div>
                        <div className="row">
                            <label> Year: </label>
                            <div> {this.state.art.year}</div>
                        </div>
                        <div className="row">
                            <label> Medium: </label>
                            <div> {this.state.art.medium}</div>
                        </div>
                        <div className="row">
                            <label> Dimensions: </label>
                            <div> {this.state.art.dimensions}</div>
                        </div>
                        <div className="row">
                            <label> Price: </label>
                            <div> {this.state.art.price}</div>
                        </div>
                        <div className="row">
                            <label> Category: </label>
                            <div> {this.state.artCategory}</div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ViewArtComponent;
