import React, { Component } from 'react';
import ArtService from '../services/ArtService';
import '../styles.css';

class CreateArtComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            id: this.props.match.params.id,
            title: '',
            artist: '',
            year: '',
            medium: '',
            dimensions: '',
            price: '',
            artCategory: 'Paintings', // Default category
            image: null
        };

        this.handleChange = this.handleChange.bind(this);
        this.saveOrUpdateArt = this.saveOrUpdateArt.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
    }

    componentDidMount() {
        if (this.state.id !== '_add') {
            ArtService.getArtById(this.state.id).then((res) => {
                let art = res.data;
                this.setState({
                    title: art.title,
                    artist: art.artist,
                    year: art.year,
                    medium: art.medium,
                    dimensions: art.dimensions,
                    price: art.price,
                    artCategory: art.artCategory,
                });
            });
        }
    }

    handleChange(event) {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    handleFileChange(event) {
        this.setState({ image: event.target.files[0] });
    }

    saveOrUpdateArt(e) {
        e.preventDefault();

        if (!this.state.title || !this.state.artist || !this.state.year || !this.state.price) {
            alert('Please fill in all required fields.');
            return;
        }

        const formData = new FormData();
        formData.append('title', this.state.title);
        formData.append('artist', this.state.artist);
        formData.append('year', this.state.year);
        formData.append('medium', this.state.medium);
        formData.append('dimensions', this.state.dimensions);
        formData.append('price', this.state.price);
        formData.append('artCategory', this.state.artCategory);
        if (this.state.image) {
            formData.append('image', this.state.image);
        }

        if (this.state.id === '_add') {
            ArtService.createArt(formData).then(() => {
                this.props.history.push('/artworks');
            });
        } else {
            ArtService.updateArt(formData, this.state.id).then(() => {
                this.props.history.push('/artworks');
            });
        }
    }

    render() {
        const transparentBackground = {
            backgroundColor: 'rgba(255, 255, 255, 0.5)',
            padding: '20px',
            borderRadius: '10px',
        };

        return (
            <div>
                <br />
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3" style={transparentBackground}>
                            <h3 className="text-center">{this.state.id === '_add' ? 'Add Art' : 'Update Art'}</h3>
                            <div className="card-body">
                                <form onSubmit={this.saveOrUpdateArt}>
                                    <div className="form-group">
                                        <label htmlFor="artCategory">Art Category: </label>
                                        <select
                                            id="artCategory"
                                            name="artCategory"
                                            className="form-control"
                                            value={this.state.artCategory}
                                            onChange={this.handleChange}
                                        >
                                            <option value="Paintings">Paintings</option>
                                            <option value="Sculptures">Sculptures</option>
                                            <option value="Installations">Installations</option>
                                            <option value="Photographs">Photographs</option>
                                            <option value="DigitalArtPieces">Digital Art Pieces</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="title">Art Title: </label>
                                        <input
                                            type="text"
                                            id="title"
                                            name="title"
                                            className="form-control"
                                            placeholder="Enter Art Title"
                                            value={this.state.title}
                                            onChange={this.handleChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="artist">Artist: </label>
                                        <input
                                            type="text"
                                            id="artist"
                                            name="artist"
                                            className="form-control"
                                            placeholder="Enter Artist Name"
                                            value={this.state.artist}
                                            onChange={this.handleChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="year">Year: </label>
                                        <input
                                            type="number"
                                            id="year"
                                            name="year"
                                            className="form-control"
                                            placeholder="Enter Year"
                                            value={this.state.year}
                                            onChange={this.handleChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="medium">Medium: </label>
                                        <input
                                            type="text"
                                            id="medium"
                                            name="medium"
                                            className="form-control"
                                            placeholder="Enter Medium"
                                            value={this.state.medium}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="dimensions">Dimensions: </label>
                                        <input
                                            type="text"
                                            id="dimensions"
                                            name="dimensions"
                                            className="form-control"
                                            placeholder="Enter Dimensions"
                                            value={this.state.dimensions}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="price">Price: </label>
                                        <input
                                            type="number"
                                            id="price"
                                            name="price"
                                            className="form-control"
                                            placeholder="Enter Price"
                                            value={this.state.price}
                                            onChange={this.handleChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="image">Image: </label>
                                        <input
                                            type="file"
                                            id="image"
                                            name="image"
                                            className="form-control"
                                            onChange={this.handleFileChange}
                                        />
                                    </div>
                                    <button type="submit" className="btn btn-success">
                                        {this.state.id === '_add' ? 'Save' : 'Update'}
                                    </button>
                                    <button
                                        className="btn btn-danger"
                                        onClick={() => this.props.history.push('/artworks')}
                                        style={{ marginLeft: '10px' }}
                                    >
                                        Cancel
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CreateArtComponent;
