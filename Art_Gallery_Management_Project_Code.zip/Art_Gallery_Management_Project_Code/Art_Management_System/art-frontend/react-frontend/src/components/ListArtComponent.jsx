import React, { Component } from 'react';
import ArtService from '../services/ArtService';
import { saveAs } from 'file-saver';
import '../styles2.css';

class ListArtComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            artworks: [],
            filteredArts: [],
            searchTerm: '',
            selectedCategory: 'All',
        };
        this.handleSearch = this.handleSearch.bind(this);
        this.viewArt = this.viewArt.bind(this);
        this.editArt = this.editArt.bind(this);
        this.deleteArt = this.deleteArt.bind(this);
        this.addArt = this.addArt.bind(this);
        this.exportArts = this.exportArts.bind(this);
        this.filterByCategory = this.filterByCategory.bind(this);
        this.goToExhibition = this.goToExhibition.bind(this);
    }

    componentDidMount() {
        this.fetchArts();
    }

    fetchArts() {
        ArtService.getArts().then((res) => {
            this.setState({
                artworks: res.data,
                filteredArts: res.data,
            });
        });
    }

    handleSearch(event) {
        this.setState({ searchTerm: event.target.value }, this.applyFilters);
    }

    applyFilters() {
        const { artworks, searchTerm, selectedCategory } = this.state;
        let filteredArts = artworks;

        if (selectedCategory !== 'All') {
            filteredArts = filteredArts.filter(art => art.artCategory === selectedCategory);
        }

        if (searchTerm) {
            filteredArts = filteredArts.filter(
                (art) =>
                    (art.title + '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                    art.artist.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    (art.year + '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                    (art.price + '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                    art.artCategory.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        this.setState({ filteredArts });
    }

    filterByCategory(category) {
        this.setState({ selectedCategory: category }, this.applyFilters);
    }

    viewArt(id) {
        this.props.history.push(`/view-art/${id}`);
    }

    editArt(id) {
        this.props.history.push(`/add-art/${id}`);
    }

    deleteArt(id) {
        ArtService.deleteArt(id).then((res) => {
            this.fetchArts();
        });
    }

    addArt() {
        this.props.history.push('/add-art/_add');
    }

    exportArts() {
        const { filteredArts } = this.state;
        const csvData = [
            ['Title', 'Artist', 'Year', 'Price', 'Category'],
            ...filteredArts.map(art => [art.title, art.artist, art.year, art.price, art.artCategory])
        ];

        const csvString = csvData.map(row => row.join(',')).join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8' });
        saveAs(blob, 'artworks.csv');
    }

    goToExhibition() {
        this.props.history.push('/exhibition');
    }

    render() {
        return (
            <div>
               

                <section id="home">
                    <div className="container">
                        <h2 className="text-center">Arts List</h2>
                        <div className="row">
                            <div className="col-md-6">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Search by title, artist, or category"
                                    value={this.state.searchTerm}
                                    onChange={this.handleSearch}
                                />
                            </div>
                        </div>
                        <br />

                        <div className="button-container">
                            <button onClick={() => this.filterByCategory('All')} className="btn btn-update">All</button>
                            <button onClick={() => this.filterByCategory('Paintings')} className="btn btn-update">Paintings</button>
                            <button onClick={() => this.filterByCategory('Sculptures')} className="btn btn-update">Sculptures</button>
                            <button onClick={() => this.filterByCategory('Installations')} className="btn btn-update">Installations</button>
                            <button onClick={() => this.filterByCategory('Photographs')} className="btn btn-update">Photographs</button>
                            <button onClick={() => this.filterByCategory('DigitalArtPieces')} className="btn btn-update">Digital Art Pieces</button>
                            <button onClick={this.addArt} className="btn btn-add">Add Art</button>
                            <button onClick={this.exportArts} className="btn btn-add">Export Arts</button>
                            <button onClick={this.goToExhibition} className="btn btn-add">Exhibition</button>
                        </div>

                        <div className="table-container">
                            <table className="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Artist</th>
                                        <th>Year</th>
                                        <th>Price</th>
                                        <th>Category</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.filteredArts.map((art) => (
                                        <tr key={art.id}>
                                            <td>
                                                {art.image && (
                                                    <img 
                                                        src={`data:image/png;base64,${art.image}`} 
                                                        alt={art.title} 
                                                        width="100" 
                                                        height="auto" 
                                                        className="img-fluid" 
                                                    />
                                                )}
                                            </td>
                                            <td>{art.title}</td>
                                            <td>{art.artist}</td>
                                            <td>{art.year}</td>
                                            <td>{art.price}</td>
                                            <td>{art.artCategory}</td>
                                            <td>
                                                <button onClick={() => this.editArt(art.id)} className="btn btn-update">
                                                    Update
                                                </button>
                                                <button
                                                    style={{ marginLeft: '10px' }}
                                                    onClick={() => this.deleteArt(art.id)}
                                                    className="btn btn-delete"
                                                >
                                                    Delete
                                                </button>
                                                <button
                                                    style={{ marginLeft: '10px' }}
                                                    onClick={() => this.viewArt(art.id)}
                                                    className="btn btn-view"
                                                >
                                                    View
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>

                

                <footer className="bg-light text-center text-lg-start">
                    <div className="container p-4">
                        <div className="row">
                            <div className="col-lg-6 col-md-12 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Art Gallery</h5>
                                <p>
                                    Bringing art closer to people. Discover, appreciate, and purchase art from our 
                                    diverse collection.
                                </p>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Links</h5>
                                <ul className="list-unstyled mb-0">
                                    <li><a href="#home" className="text-dark">Home</a></li>
                                    <li><a href="#about" className="text-dark">About Us</a></li>
                                    <li><a href="#contact" className="text-dark">Contact Us</a></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Follow Us</h5>
                                <ul className="list-unstyled mb-0">
                                    <li><a href="#!" className="text-dark">Facebook</a></li>
                                    <li><a href="#!" className="text-dark">Twitter</a></li>
                                    <li><a href="#!" className="text-dark">Instagram</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="text-center p-3">
                        © 2024 Art Gallery. All rights reserved.
                    </div>
                </footer>
            </div>
        );
    }
}

export default ListArtComponent;
