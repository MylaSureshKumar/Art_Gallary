import React, { Component } from 'react';
import ArtService from '../services/ArtService';
import '../style4.css';

class BuyArtComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            art: {},
            purchaseSuccess: false
        };
    }

    componentDidMount() {
        const artId = this.props.match.params.id;
        this.fetchArtDetails(artId);
    }

    fetchArtDetails(artId) {
        ArtService.getArtById(artId).then((res) => {
            this.setState({ art: res.data });
        }).catch(err => {
            console.error("There was an error fetching the artwork details!", err);
        });
    }

    handleSubmit() {
        // Simulate a purchase process
        this.setState({ purchaseSuccess: true });
    }

    render() {
        const { art, purchaseSuccess } = this.state;

        return (
            <div className="container">
                <header>
                    <nav className="navbar navbar-expand-lg navbar-light bg-light">
                        <a className="navbar-brand" href="#">Art Gallery</a>
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <a className="nav-link" href="/">Home</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="/about">About Us</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="/contact">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header>

                <section id="buy-art">
                    <div className="container">
                        <h2 className="text-center">Purchase Artwork</h2>
                        {purchaseSuccess ? (
                            <div className="alert alert-success" role="alert">
                                Your purchase was successful!
                            </div>
                        ) : (
                            <div className="card">
                                {art.image && (
                                    <img
                                        src={`data:image/jpeg;base64,${art.image}`}
                                        alt={art.title}
                                        className="card-img-top"
                                    />
                                )}
                                <div className="card-body">
                                    <h5 className="card-title">{art.title}</h5>
                                    <p className="card-text">{art.artist}</p>
                                    <p className="card-text">${art.price}</p>
                                    <button
                                        className="btn btn-update"
                                        onClick={() => this.handleSubmit()}
                                    >
                                        Submit
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </section>

                <footer className="bg-light text-center text-lg-start">
                    <div className="container p-4">
                        <div className="row">
                            <div className="col-lg-6 col-md-12 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Art Gallery</h5>
                                <p>
                                    Bringing art closer to people. Discover, appreciate, and purchase art from our 
                                    diverse collection.
                                </p>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Links</h5>
                                <ul className="list-unstyled mb-0">
                                    <li><a href="#!" className="text-dark">Home</a></li>
                                    <li><a href="#!" className="text-dark">About Us</a></li>
                                    <li><a href="#!" className="text-dark">Contact Us</a></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-md-6 mb-4 mb-md-0">
                                <h5 className="text-uppercase">Follow Us</h5>
                                <ul className="list-unstyled mb-0">
                                    <li><a href="#!" className="text-dark">Facebook</a></li>
                                    <li><a href="#!" className="text-dark">Twitter</a></li>
                                    <li><a href="#!" className="text-dark">Instagram</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="text-center p-3">
                        © 2024 Art Gallery. All rights reserved.
                    </div>
                </footer>
            </div>
        );
    }
}

export default BuyArtComponent;
