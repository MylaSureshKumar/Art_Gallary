import React, { Component } from 'react';
import ArtService from '../services/ArtService';
import '../styles.css';

class UpdateArtComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: this.props.match.params.id,
            title: '',
            artist: '',
            year: '',
            medium: '',
            dimensions: '',
            price: '',
            artCategory: '', // Initialize category field
            imageFile: null
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
        this.updateArt = this.updateArt.bind(this);
    }

    componentDidMount() {
        ArtService.getArtById(this.state.id).then((res) => {
            const art = res.data;
            this.setState({
                title: art.title,
                artist: art.artist,
                year: art.year,
                medium: art.medium,
                dimensions: art.dimensions,
                price: art.price,
                artCategory: art.artCategory, // Set category from fetched data
            });
        });
    }

    handleChange(event) {
        const { name, value } = event.target;
        this.setState({ [name]: value });
    }

    handleFileChange(event) {
        this.setState({ imageFile: event.target.files[0] });
    }

    updateArt(event) {
        event.preventDefault();
        const { id, title, artist, year, medium, dimensions, price, artCategory, imageFile } = this.state;

        const formData = new FormData();
        formData.append('title', title);
        formData.append('artist', artist);
        formData.append('year', year);
        formData.append('medium', medium);
        formData.append('dimensions', dimensions);
        formData.append('price', price);
        formData.append('artCategory', artCategory);
        if (imageFile) {
            formData.append('image', imageFile);
        }

        ArtService.updateArt(formData, id).then(() => {
            this.props.history.push('/artworks');
        });
    }

    render() {
        const transparentBackground = {
            backgroundColor: 'rgba(255, 255, 255, 0.5)',
            padding: '20px',
            borderRadius: '10px'
        };

        return (
            <div>
                <br />
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3" style={transparentBackground}>
                            <h3 className="text-center">Update Art</h3>
                            <div className="card-body">
                                <form onSubmit={this.updateArt}>
                                    <div className="form-group">
                                        <label htmlFor="artCategory">Art Category:</label>
                                        <select
                                            id="artCategory"
                                            name="artCategory"
                                            className="form-control"
                                            value={this.state.artCategory}
                                            onChange={this.handleChange}
                                        >
                                            <option value="Paintings">Paintings</option>
                                            <option value="Sculptures">Sculptures</option>
                                            <option value="Installations">Installations</option>
                                            <option value="Photographs">Photographs</option>
                                            <option value="DigitalArtPieces">Digital Art Pieces</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label>Title:</label>
                                        <input
                                            type="text"
                                            name="title"
                                            className="form-control"
                                            value={this.state.title}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Artist:</label>
                                        <input
                                            type="text"
                                            name="artist"
                                            className="form-control"
                                            value={this.state.artist}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Year:</label>
                                        <input
                                            type="number"
                                            name="year"
                                            className="form-control"
                                            value={this.state.year}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Medium:</label>
                                        <input
                                            type="text"
                                            name="medium"
                                            className="form-control"
                                            value={this.state.medium}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Dimensions:</label>
                                        <input
                                            type="text"
                                            name="dimensions"
                                            className="form-control"
                                            value={this.state.dimensions}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Price:</label>
                                        <input
                                            type="number"
                                            name="price"
                                            className="form-control"
                                            value={this.state.price}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Image:</label>
                                        <input
                                            type="file"
                                            name="imageFile"
                                            className="form-control"
                                            onChange={this.handleFileChange}
                                        />
                                    </div>
                                    <button type="submit" className="btn btn-success">
                                        Save
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-danger"
                                        onClick={() => this.props.history.push('/artworks')}
                                        style={{ marginLeft: '10px' }}
                                    >
                                        Cancel
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default UpdateArtComponent;
