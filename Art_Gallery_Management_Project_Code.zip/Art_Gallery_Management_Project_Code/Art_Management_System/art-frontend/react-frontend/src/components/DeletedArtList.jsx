import React, { useState, useEffect } from 'react';
import ArtService from '../services/ArtService';

const DeletedArtList = () => {
    const [deletedArts, setDeletedArts] = useState([]);

    useEffect(() => {
        console.log('Fetching deleted arts...');
        fetchDeletedArts();
    }, []);

    const fetchDeletedArts = async () => {
        try {
            const response = await ArtService.getDeletedArts();
            console.log('Fetched deleted arts:', response.data);
            setDeletedArts(response.data);
        } catch (error) {
            console.error('Error fetching deleted arts:', error);
        }
    };

    console.log('Deleted arts state:', deletedArts);

    return (
        <div>
            <h2>Deleted Arts</h2>
            <ul>
                {deletedArts.map((art) => (
                    <li key={art.id}>{art.title} {art.artist} {art.year} {art.price}</li>
                ))}
            </ul>
        </div>
    );
};

export default DeletedArtList;