package com.neo.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.neo.springboot.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Custom query method to find a user by username
    User findByUsername(String username);

    // Custom query method to check if a user exists by username
    boolean existsByUsername(String username);

    // Custom query method to delete a user by username
    void deleteByUsername(String username);

    // Add more custom query methods as needed based on your application's requirements
}
