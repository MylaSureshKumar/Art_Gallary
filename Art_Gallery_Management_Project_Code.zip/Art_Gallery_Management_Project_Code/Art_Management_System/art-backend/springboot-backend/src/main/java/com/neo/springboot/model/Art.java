package com.neo.springboot.model;

import javax.persistence.*;

@Entity
@Table(name = "artworks")
public class Art {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Lob
    @Column(name = "image", nullable = true)
    private byte[] image; // Field to store image data

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "artist", nullable = false)
    private String artist;

    @Column(name = "year", nullable = false)
    private Integer year;

    @Column(name = "medium", nullable = true)
    private String medium;

    @Column(name = "dimensions", nullable = true)
    private String dimensions;

    @Column(name = "price", nullable = false)
    private Double price;

    @Column(name = "art_category", nullable = false)
    private String artCategory;

    public Art() {
    }

    public Art(byte[] image, String title, String artist, Integer year, String medium, String dimensions, Double price, String artCategory) {
        this.image = image;
        this.title = title;
        this.artist = artist;
        this.year = year;
        this.medium = medium;
        this.dimensions = dimensions;
        this.price = price;
        this.artCategory = artCategory;
    }

    // Getters and setters

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getMedium() {
        return medium;
    }

    public void setMedium(String medium) {
        this.medium = medium;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getArtCategory() {
        return artCategory;
    }

    public void setArtCategory(String artCategory) {
        this.artCategory = artCategory;
    }
}
