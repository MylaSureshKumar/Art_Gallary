package com.neo.springboot.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.neo.springboot.exception.ResourceNotFoundException;
import com.neo.springboot.model.Art;
import com.neo.springboot.repository.ArtRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/")
public class ArtController {

    @Autowired
    private ArtRepository artRepository;

    // Get all artworks
    @GetMapping("/artworks")
    public List<Art> getAllArts() {
        return artRepository.findAll();
    }

    // Create artwork with image upload
    @PostMapping("/artworks")
    public Art createArt(
            @RequestParam(value = "image", required = false) MultipartFile image, 
            @RequestParam("title") String title,
            @RequestParam("artist") String artist,
            @RequestParam("year") Integer year,
            @RequestParam("medium") String medium,
            @RequestParam("dimensions") String dimensions,
            @RequestParam("price") Double price,
            @RequestParam("artCategory") String artCategory) throws IOException {

        byte[] imageData = null;
        if (image != null && !image.isEmpty()) {
            imageData = image.getBytes();
            System.out.println("Image uploaded: " + image.getOriginalFilename() + ", size: " + image.getSize());
        } else {
            System.out.println("No image uploaded");
        }

        Art art = new Art(imageData, title, artist, year, medium, dimensions, price, artCategory);
        return artRepository.save(art);
    }

    // Get artwork by id
    @GetMapping("/artworks/{id}")
    public ResponseEntity<Art> getArtById(@PathVariable Long id) {
        Art art = artRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Art not exist with id :" + id));
        return ResponseEntity.ok(art);
    }

    // Update artwork
    @PutMapping("/artworks/{id}")
    public ResponseEntity<Art> updateArt(
            @PathVariable Long id,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam("title") String title,
            @RequestParam("artist") String artist,
            @RequestParam("year") Integer year,
            @RequestParam("medium") String medium,
            @RequestParam("dimensions") String dimensions,
            @RequestParam("price") Double price,
            @RequestParam("artCategory") String artCategory) throws IOException {

        Art art = artRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Art not exist with id :" + id));

        if (image != null && !image.isEmpty()) {
            byte[] imageData = image.getBytes();
            art.setImage(imageData);
            System.out.println("Image uploaded: " + image.getOriginalFilename() + ", size: " + image.getSize());
        } else {
            System.out.println("No image uploaded");
        }

        art.setTitle(title);
        art.setArtist(artist);
        art.setYear(year);
        art.setMedium(medium);
        art.setDimensions(dimensions);
        art.setPrice(price);
        art.setArtCategory(artCategory);

        Art updatedArt = artRepository.save(art);
        return ResponseEntity.ok(updatedArt);
    }

    // Delete artwork
    @DeleteMapping("/artworks/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteArt(@PathVariable Long id) {
        Art art = artRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Art not exist with id :" + id));

        artRepository.delete(art);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }
}
