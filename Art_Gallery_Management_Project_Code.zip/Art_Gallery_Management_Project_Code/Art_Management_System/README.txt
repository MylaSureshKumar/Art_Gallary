LOGIN:
             
USERNAME : 'admin'

PASSWORD : 'password'